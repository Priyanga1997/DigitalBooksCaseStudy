﻿using UserMicroservice.Models;

namespace UserMicroservice.Services
{
    public interface IUser
    {
        Task<string> Login(User login, bool IsRegister);
        Task<string> Register(User login, bool IsRegister);
    }
}
