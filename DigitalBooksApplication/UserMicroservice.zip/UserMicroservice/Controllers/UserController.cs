﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using NuGet.Protocol.Plugins;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using UserMicroservice.Models;
using UserMicroservice.Services;

namespace UserMicroservice.Controllers
{
    public class UserController : Controller
    {
        public IConfiguration _config;
        IUser _user;
        public UserController(IConfiguration config, IUser user)
        {
            _config = config;
            _user = user;
        }

        [HttpGet]
        [Route("User/Login")]
        public IActionResult Login()
        {
            User login = new User();
            return View(login);
        }

        [HttpPost]
        [Route("User/Login")]
        public async Task<IActionResult> Login(User login)
        {
            IActionResult response = Unauthorized();
            var userdata = await _user.Login(login, false);
            if (login != null)
            {
                response = Ok(new { token = userdata });
            }
            return View(response);
        }

        [HttpGet]
        [Route("User/Register")]
        public IActionResult Register()
        {
            User login = new User();
            return View(login);
        }

        [HttpPost]
        [Route("User/Register")]
        public async Task<IActionResult> Register(User login)
        {
            IActionResult response = Unauthorized();
            var userdata = await _user.Register(login, true);
            if (login != null)
            {
                response = Ok(new { token = userdata });
            }
            return View(response);
        }

    }
}
